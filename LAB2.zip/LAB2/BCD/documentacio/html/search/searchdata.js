var indexSectionsWithContent =
{
  0: "abcefimnrstxyz",
  1: "cefmrs",
  2: "cr",
  3: "cmrs",
  4: "abceimnrstxyz"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Namespaces",
  3: "Archivos",
  4: "Variables"
};

